package com.tbc.multithreading.Example4;

public class Class_1 {
	public void greet() {
		System.out.println("Greet method of Class_1");
	}
}
