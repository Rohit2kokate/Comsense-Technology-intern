package com.tbc.multithreading.Example5;

public class Test extends Thread{
	public void run() {
		System.out.println("This is Test Thread..!");
	}
}
