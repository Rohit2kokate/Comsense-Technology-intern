package com.tbc.multithreading.Example5;

public class Demo extends Thread{
	public void run() {
		System.out.println("This is Demo Thread..!");
	}
}
