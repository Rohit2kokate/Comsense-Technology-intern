package com.intern.constructor;

public class suKeyword {
	public suKeyword() {
		// TODO Auto-generated constructor stub
	}
}
